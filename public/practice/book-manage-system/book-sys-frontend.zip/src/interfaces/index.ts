import axios from "axios";
import type { UpdateBook } from "../BookManage/UpdateBookModal";

export interface CreateBook {
  title: string;
  author: string;
  description: string;
  price: number;
  category: string;
  publishedDate: string;
  link: string;
}
const axiosInstance = axios.create({
  baseURL: 'http://localhost:3000/',
  timeout: 3000
});

// 注册
export async function register(username: string, password: string) {
  return await axiosInstance.post('/user/register', {
    username, password
  });
}
// 登录
export async function login(username: string, password: string) {
  return await axiosInstance.post('/user/login', {
    username, password
  });
}
// 获取书籍列表
export async function getBooks(name: string) {

  return await axiosInstance.get('/book/list', {
    params: {
      name
    }
  });
}

// 获取书籍详情
export async function getBookDetail(bookId: number) {
  return await axiosInstance.get(`/book/detail/${bookId}`);
}

// 创建书籍
export async function createBook(book: CreateBook) {
  return await axiosInstance.post('book/add', {
    title: book.title,
    author: book.author,
    description: book.description,
    price: book.price,
    category: book.category,
    publishedDate: book.publishedDate,
    link: book.link
  });
}
// 更新书籍
export async function updateBook(book: UpdateBook) {
  return await axiosInstance.patch(`/book/update/${book.id}`, {
    title: book.title,
    author: book.author,
    description: book.description,
    price: book.price,
    category: book.category,
    publishedDate: book.publishedDate,
    link: book.link
  });
}

// 删除书籍
export async function deleteBook(id: number) {
  return await axiosInstance.delete(`/book/delete/${id}`);
}