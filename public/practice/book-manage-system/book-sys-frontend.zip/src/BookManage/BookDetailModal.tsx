import { useEffect } from "react";
import { Form, Input, Modal, message } from "antd";
import { useForm } from "antd/es/form/Form";
import { getBookDetail } from "../interfaces/index";
import TextArea from "antd/es/input/TextArea";

interface UpdateBookModalProps {
  id: number;
  isOpen: boolean;
  handleClose: () => void;
}
const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

export interface UpdateBook {
  id: number;
  title: string;
  author: string;
  description: string;
  price: number;
  category: string;
  publishedDate: string;
  link: string;
}

export function BookDetailModal(props: UpdateBookModalProps) {
  const [form] = useForm<UpdateBook>();

  async function query() {
    if (!props.id) {
      return;
    }
    try {
      const res = await getBookDetail(props.id);
      const { data } = res;
      if (res.status === 200 || res.status === 201) {
        form.setFieldValue("id", data.id);
        form.setFieldValue("title", data.title);
        form.setFieldValue("author", data.author);
        form.setFieldValue("description", data.description);
        form.setFieldValue("price", data.price);
        form.setFieldValue("category", data.category);
        form.setFieldValue("publishedDate", data.publishedDate);
        form.setFieldValue("link", data.link);
      }
    } catch (e: any) {
      message.error(e.response.data.message);
    }
  }

  useEffect(() => {
    query();
  }, [props.id]);

  return (
    <Modal
      title="图书详情"
      open={props.isOpen}
      onCancel={() => props.handleClose()}
    >
      <Form form={form} colon={false} {...layout}>
        <Form.Item label="图书名称" name="title">
          <Input disabled />
        </Form.Item>
        <Form.Item label="作者" name="author">
          <Input disabled />
        </Form.Item>
        <Form.Item label="描述" name="description">
          <TextArea disabled rows={4} />
        </Form.Item>
        <Form.Item label="价格" name="price">
          <Input disabled />
        </Form.Item>
        <Form.Item label="分类" name="category">
          <Input disabled />
        </Form.Item>
        <Form.Item label="日期" name="publishedDate">
          <Input disabled />
        </Form.Item>
        <Form.Item label="封面" name="link">
          <Input disabled />
        </Form.Item>
      </Form>
    </Modal>
  );
}
