import { Module } from '@nestjs/common';
import { APP_PIPE } from '@nestjs/core';

import { AppController } from './app.controller';
import { AppService } from './app.service';

import { UserModule } from './modules/user/user.module';
import { BookModule } from './modules/book/book.module';
import { JsonReaderModule } from './common/json-reader/json-reader.module';

import { MyValidationPipe } from './common/my-validation/my-validation.pipe';

@Module({
  imports: [UserModule, BookModule, JsonReaderModule],
  controllers: [AppController],
  providers: [AppService, { provide: APP_PIPE, useClass: MyValidationPipe }],
})
export class AppModule { }
