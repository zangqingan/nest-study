export class User {
  username: string;
  password: string;
}
