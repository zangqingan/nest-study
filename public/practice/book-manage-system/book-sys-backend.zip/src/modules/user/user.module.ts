import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';

// 引入json-reader模块
import { JsonReaderModule } from '../../common/json-reader/json-reader.module';

@Module({
  controllers: [UserController],
  providers: [UserService],
  imports: [JsonReaderModule.register({ path: 'src/data/users.json' })],
})
export class UserModule { }
