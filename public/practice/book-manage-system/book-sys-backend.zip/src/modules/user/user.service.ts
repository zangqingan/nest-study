import { Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateUserDto, RegisterUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from './entities/user.entity';

import { JsonReaderService } from '../../common/json-reader/json-reader.service';

@Injectable()
export class UserService {
  @Inject(JsonReaderService)
  private readonly jsonReaderService: JsonReaderService;

  create(createUserDto: CreateUserDto) {
    return 'This action adds a new user';
  }

  findAll() {
    return `This action returns all user`;
  }

  findOne(id: number) {
    return `This action returns a #${id} user`;
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return `This action updates a #${id} user`;
  }

  remove(id: number) {
    return `This action removes a #${id} user`;
  }

  // 登录
  async login(loginDto: RegisterUserDto) {
    const users: User[] = await this.jsonReaderService.readJsonFile();
    const foundUser = users.find(
      (user) =>
        user.username === loginDto.username &&
        user.password === loginDto.password,
    );
    if (!foundUser) {
      throw new UnauthorizedException('用户名或密码错误');
    }
    return foundUser;
  }

  // 注册
  async register(registerUserDto: RegisterUserDto) {
    // 读取文件
    const usersArr = await this.jsonReaderService.readJsonFile();
    console.log('usersArr', usersArr);
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-call, @typescript-eslint/no-unsafe-member-access
    const foundUser = usersArr.find(
      (user: RegisterUserDto) => user.username === registerUserDto.username,
    );
    if (foundUser) {
      throw new UnauthorizedException('用户已存在');
    }

    // 如果没有找到用户，则返回注册信息

    const user = new User();
    user.username = registerUserDto.username;
    user.password = registerUserDto.password;
    usersArr.push(user);
    this.jsonReaderService.writeJsonFile(usersArr);

    return user;
  }
}
