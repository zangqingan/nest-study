export class Book {
  id: number;
  title: string;
  author: string;
  description: string;
  price: number;
  category: string;
  publishedDate: Date;
  link: string;
}
