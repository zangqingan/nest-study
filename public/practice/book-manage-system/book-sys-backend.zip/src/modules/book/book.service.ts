import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';
import { JsonReaderService } from '../../common/json-reader/json-reader.service';
import { Book } from './entities/book.entity';
@Injectable()
export class BookService {
  @Inject(JsonReaderService)
  private jsonReaderService: JsonReaderService;

  async create(createBookDto: CreateBookDto) {
    const books: Book[] = await this.jsonReaderService.readJsonFile();
    if (!books) {
      throw new Error('Books data not found');
    }
    const newId = books.length
      ? Math.max(...books.map((book) => book.id)) + 1
      : 1;
    const newBook = new Book();
    newBook.id = newId;
    newBook.title = createBookDto.title;
    newBook.author = createBookDto.author;
    newBook.description = createBookDto.description;
    newBook.price = createBookDto.price;
    newBook.category = createBookDto.category;
    newBook.publishedDate = createBookDto.publishedDate;
    newBook.link = createBookDto.link;
    books.push(newBook);
    await this.jsonReaderService.writeJsonFile(books);
    return newBook;
  }

  findAll(name: string) {
    const books = this.jsonReaderService.readJsonFile();
    if (name) {
      return books.filter((book) => book.title.includes(name));
    }
    return books as Book[];
  }

  async findOne(id: number) {
    const books: Book[] = await this.jsonReaderService.readJsonFile();
    const book = books.find((book) => book.id === id);
    if (!book) {
      throw new NotFoundException('Book not found');
    }
    return book;
  }

  async update(id: number, updateBookDto: UpdateBookDto) {
    const books = await this.jsonReaderService.readJsonFile();
    const book = books.find((book) => book.id === id);
    if (!book) {
      throw new NotFoundException('Book not found');
    }
    book.title = updateBookDto.title;
    book.author = updateBookDto.author;
    book.description = updateBookDto.description;
    book.price = updateBookDto.price;
    book.category = updateBookDto.category;
    book.publishedDate = updateBookDto.publishedDate;
    book.link = updateBookDto.link;
    await this.jsonReaderService.writeJsonFile(books);
    return book;
  }

  async remove(id: number) {
    const books: Book[] = await this.jsonReaderService.readJsonFile();
    const updatedBooks = books.filter((book) => book.id !== id);
    await this.jsonReaderService.writeJsonFile(updatedBooks);
    return books.find((book) => book.id === id);
  }
}
