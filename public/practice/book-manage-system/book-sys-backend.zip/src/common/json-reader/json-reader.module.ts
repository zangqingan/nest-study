import { DynamicModule, Module } from '@nestjs/common';
import { JsonReaderService } from './json-reader.service';

export interface JsonReaderOptions {
  path: string;
}

@Module({})
export class JsonReaderModule {
  public static register(options: JsonReaderOptions): DynamicModule {
    return {
      module: JsonReaderModule,
      providers: [
        {
          provide: 'JSON_READER_OPTIONS',
          useValue: options,
        },
        JsonReaderService,
      ],
      exports: [JsonReaderService],
    };
  }
}
