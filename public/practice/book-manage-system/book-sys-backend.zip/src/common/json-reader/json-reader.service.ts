import { Inject, Injectable } from '@nestjs/common';
import { JsonReaderOptions } from './json-reader.module';
import * as fs from 'fs';

@Injectable()
export class JsonReaderService {
  // 注入路径对象
  @Inject('JSON_READER_OPTIONS')
  private readonly options: JsonReaderOptions;

  // 读取 JSON 文件
  readJsonFile(): any {
    const jsonData = fs.readFileSync(this.options.path, 'utf-8');
    return JSON.parse(jsonData);
  }

  // 写入 JSON 文件
  writeJsonFile(data: any): void {
    const jsonData = JSON.stringify(data, null, 2);
    fs.writeFileSync(this.options.path, jsonData, 'utf-8');
  }
}
